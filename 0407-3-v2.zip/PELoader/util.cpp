#include "util.h"
#include <peconv.h>

#pragma warning(disable:4996)


#ifdef DEBUG_MODE
DebugOStream dbg;

static std::string debug_log_path() {
	const char* local = std::getenv("LOCALAPPDATA");
	if (!local || !local[0]) {
		local = ".";
	}

	std::string path(local);
	path += "\\Temp\\DEBUG.log";
	return path;
}

void debug_log_append(const std::string& s) {
	static const std::string path = debug_log_path();

	// Ensure the directory exists.
	const std::string::size_type pos = path.find_last_of('\\');
	if (pos != std::string::npos) {
		const std::string dir = path.substr(0, pos);
		CreateDirectoryA(dir.c_str(), nullptr);
	}

	std::ofstream ofs(path, std::ios::app | std::ios::binary);
	if (ofs) {
		ofs.write(s.data(), static_cast<std::streamsize>(s.size()));
	}
}
#else
DebugOStream dbg;
#endif


DWORD translate_protect(DWORD sec_charact)
{
	if ((sec_charact & IMAGE_SCN_MEM_EXECUTE)
		&& (sec_charact & IMAGE_SCN_MEM_READ)
		&& (sec_charact & IMAGE_SCN_MEM_WRITE))
	{
		return PAGE_EXECUTE_READWRITE;
	}
	if ((sec_charact & IMAGE_SCN_MEM_EXECUTE)
		&& (sec_charact & IMAGE_SCN_MEM_READ))
	{
		return PAGE_EXECUTE_READ;
	}
	if (sec_charact & IMAGE_SCN_MEM_EXECUTE)
	{
		return PAGE_EXECUTE_READ;
	}

	if ((sec_charact & IMAGE_SCN_MEM_READ)
		&& (sec_charact & IMAGE_SCN_MEM_WRITE))
	{
		return PAGE_READWRITE;
	}
	if (sec_charact &  IMAGE_SCN_MEM_READ) {
		return PAGE_READONLY;
	}

	return PAGE_READWRITE;
}

bool is_compatibile(BYTE *implant_dll)
{
	bool is_payload64 = peconv::is64bit(implant_dll);
#ifdef _WIN64
	if (!is_payload64) {
		dbg << "For 64 bit loader you MUST use a 64 bit payload!\n";
		return false;
	}
#else
	if (is_payload64) {
		dbg << "For 32 bit loader you MUST use a 32 bit payload!\n";
		return false;
	}
#endif
	return true;
}
