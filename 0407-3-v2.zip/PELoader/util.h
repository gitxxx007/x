#pragma once

#include <Windows.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <cstring>

DWORD translate_protect(DWORD sec_charact);
bool is_compatibile(BYTE* implant_dll);

// Debug logging:
// When `DEBUG_MODE` is defined, all `dbg << ...` output is appended to:
//   %LOCALAPPDATA%\\Temp\\DEBUG.log
// Otherwise, `dbg` compiles but produces no output.
#ifdef DEBUG_MODE
void debug_log_append(const std::string& s);

class DebugOStream {
public:
	DebugOStream() = default;
	~DebugOStream() { flush(); }

	template <typename T>
	DebugOStream& operator<<(const T& v) {
		oss << v;
		return *this;
	}

	DebugOStream& operator<<(std::ostream& (*pf)(std::ostream&)) {
		pf(oss);
		flush();
		return *this;
	}

	DebugOStream& operator<<(const char* s) {
		oss << s;
		if (s && std::strlen(s) > 0 && s[std::strlen(s) - 1] == '\n') {
			flush();
		}
		return *this;
	}

	DebugOStream& operator<<(const std::string& s) {
		oss << s;
		if (!s.empty() && s.back() == '\n') {
			flush();
		}
		return *this;
	}

	void flush() {
		const std::string current = oss.str();
		if (!current.empty()) {
			debug_log_append(current);
		}
		oss.str(std::string());
		oss.clear();
	}

private:
	std::ostringstream oss;
};

extern DebugOStream dbg;
#else
class DebugOStream {
public:
	template <typename T>
	DebugOStream& operator<<(const T&) { return *this; }

	DebugOStream& operator<<(std::ostream& (*)(std::ostream&)) { return *this; }
};

extern DebugOStream dbg;
#endif
